
#include <iostream>
#include "Stack.h"
#include "Queue.h"
#include "List.h"
#include "MyException.h"

using namespace std;

void testStack();
void testQueue();
void testList();

int main()
{
    //testQueue();
    testStack(); 
    //testList();
	return 0;
}


void testList()
{
	cout << "\n-------LIST_TEST------\n";

	List<int> l1;
	
	cout << "List1 addToBack -> 2\n"; 
	l1.addToBack(2);
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 addToFront -> 3\n";
	l1.addToFront(3);
	cout << "l1 = " << l1 << endl;
		
	cout << "List1 insertAt(1) -> 1\n";
	l1.insertAtIndex(1, 1);
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 addToBack -> 4\n"; 
	l1.addToBack(4);	
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 addToFront -> 10\n"; 
	l1.addToFront(10);	
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 get(1)-> " << l1.get(1) << endl;	

	cout << "List1 insertAtIndex(1)-> 11\n"; 
	l1.insertAtIndex(1, 11);	
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 deleteAtIndex(1)\n"; 
	l1.deleteAtIndex(1);	
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 set(0, 24)\n"; 
	l1.set(0, 24);	
	cout << "l1 = " << l1 << endl;
	
	cout << "List1 deleteAtIndex(100)\n"; 
	try{
		l1.deleteAtIndex(100);	
		cout << "l1 = " << l1 << endl;
	} catch( MyException e ){
			cout << e.getCause() << endl;
	}

	cout << "List1 set(100, 24)\n"; 
	try{
		l1.set(100, 24);	
		cout << "l1 = " << l1 << endl;
	} catch( MyException e ){
		cout << e.getCause() << endl;
	}
	cout << "List1 get(100)\n"; 
	try{
		l1.get(100);	
		cout << "l1 = " << l1 << endl;
	} catch( MyException e ){
		cout << e.getCause() << endl;
	}
	cout << "\n-------LIST_TEST COMPLETE------\n";
	
}

void testStack()
{
	cout << "\n-------\n\tSTACK_TEST\n------\n";
	Stack<int> stack1;
	cout << "Stack1 pushing -> 3\n";
	stack1.push(3);
	cout << "Stack1 pushing -> 2\n"; 
	stack1.push(2);
	cout << "Stack1 pushing -> 1\n";
	stack1.push(1);
	cout << "Stack1 = " << stack1 << "\n\n";
	
	cout << "Peeking into Stack1 -> " << stack1.peek() << "\n\n";

	cout << "Copy Constructing Stack2 from Stack1\n";
	Stack<int> stack2( stack1 );
	cout << "Stack2 = " <<  stack2 << "\n\n";

	cout << "Stack1 Pop ->" << stack1.pop() << "\n";
	cout << "Stack1 = " << stack1 << "\n\n";
	
	cout << "Assigning Stack2 to Stack1\n";
	cout << "Stack2 = " <<  stack2 << "\n\n";
	
	Stack<int> stack3;
	cout << "Creating empty Stack3\n";
	try{
		cout << "Popping Stack3\n";
		stack3.pop();
	} catch ( MyException e ){
		cout << e.getCause() << "\n\n";
	}

	try{
		cout << "Peeking into Stack3\n";
		stack3.peek();
	} catch ( MyException e ){
		cout << e.getCause() << "\n\n";
	}
	cout << "------- STACK_TEST COMPLETE ------\n";
}
void testQueue()
{
	cout << "\n-------\n\tQUEUE_TEST\n------\n";
	Queue<int> q1;
	
	cout << "Creating q1\n";
	cout << "q1 = " << q1 << "\n\n";
	cout << "q1 enqueueing -> 1\n";
	q1.enqueue(1);
	cout << "q1 = " << q1 << "\n\n";
	cout << "q1 enqueueing -> 2\n";
	q1.enqueue(2);
	cout << "q1 = " << q1 << "\n\n";
	cout << "q1 enqueueing -> 3\n";
	q1.enqueue(3);
	cout << "q1 = " << q1 << "\n\n";
	cout << "q1 enqueueing -> 4\n";
	q1.enqueue(4);
	cout << "q1 = " << q1 << "\n\n";
	
	try{
		cout << "q1 inc priority -> 4\n";
		q1.increasePriority(4);
		cout << "q1 = " << q1 << "\n\n";
		cout << "q1 inc priority -> 4\n";
		q1.increasePriority(4);
		cout << "q1 = " << q1 << "\n\n";
		cout << "q1 inc priority -> 4\n";
		q1.increasePriority(4);
		cout << "q1 = " << q1 << "\n\n";
		cout << "q1 inc priority -> 3\n";
		q1.increasePriority(3);
		cout << "q1 = " << q1 << "\n\n";
		cout << "q1 inc priority -> 3\n";
		q1.increasePriority(3);
		cout << "q1 = " << q1 << "\n\n";
		cout << "q1 inc priority -> 3\n";
		q1.increasePriority(3);
		cout << "q1 = " << q1 << "\n\n";
	} catch( MyException e ){
		cout << e.getCause() << endl;
	}
	
	cout << "q1 dequeue ->" << q1.dequeue() << endl;
	cout << "q1 dequeue ->" << q1.dequeue() << endl;
    cout << "q1 dequeue ->" << q1.dequeue() << endl;
    cout << "q1 dequeue ->" << q1.dequeue() << endl;
	cout << "q1 = " << q1 << "\n\n";
	
	cout << "q1 dequeue empty queue\n";
	try{
		q1.dequeue();
	} catch( MyException e) { cout << e.getCause() << endl;}
	
    cout << "q1.isEmpty() -> " << boolalpha << q1.isEmpty() << "\n";
	cout << "Copy constructing q2\n";
	Queue<int> q2(q1);
	cout << "q2 = " << q2 << "\n\n";
	
	cout << "q1 enqueueing -> 99\n";
	q1.enqueue(99);
	cout << "Assigning q2 to q1\n";
	q2 = q1;
	cout << "q1 = " << q1 << "\n\n";
	
	cout << "------- QUEUE_TEST COMPLETE ------\n";
}

