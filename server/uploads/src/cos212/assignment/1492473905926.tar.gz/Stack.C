/*TODO: Provide the implementation for the Stack class in this file*/

template<class T>
Stack<T>::Stack()
{
  queue = new Queue<T>();	
}

template<class T>
Stack<T>::Stack(const Stack<T>& other)
{
  queue = new Queue<T>(*other.queue);	
}


template<class T>
Stack<T>& Stack<T>::operator=(const Stack<T>& other)
{
  if(queue)
    delete queue;
  queue = new Queue<T>(*other.queue);
  return *this;
}

template<class T>
Stack<T>::~Stack()
{
  delete queue;	
}

template<class T>
void Stack<T>::push(const T& el)
{
  //create new qreue with new element as head
  Queue<T>* q = new Queue<T>();
  q->enqueue(el);
  //dequeue old queue into new queue
  while(!queue->isEmpty())
    q->enqueue(queue->dequeue());

  //replace old queue with new queue
  delete queue;
  queue = q;
}

template<class T>
T Stack<T>::pop()
{
  if(queue->isEmpty())
    throw MyException("Stack::pop() called on empty stack");
  return queue->dequeue();	
}


template<class T>
bool Stack<T>::isEmpty()
{
  return queue->isEmpty();
}

template<class T>
T Stack<T>::peek()
{
  if(queue->isEmpty())
    throw MyException("Stack::peek() called on empty stack");
  T val = pop();
  push(val);
  return val;
}

template<class T>
ostream& operator<<(ostream& os,Stack<T>& stack)
{
  os << *stack.queue; 	
  return os;
}



