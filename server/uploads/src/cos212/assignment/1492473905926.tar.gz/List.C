

template<class T>
List<T>::List()
{
  stack = new Stack<T>();
}

template<class T>
List<T>::List(const List<T>& other)
{
  if(stack)	
    delete stack;
  stack = new Stack<T>(*other.stack);
}

template<class T>
List<T>& List<T>::operator=(const List<T>& other)
{
  if(stack)	
    delete stack;
  stack = new Stack<T>(*other.stack);
  return *this;
}

template<class T>
List<T>::~List()
{
  if(stack)	
    delete stack;
}

template<class T>
void List<T>::addToFront(const T& el)
{
  stack->push(el);	
}

template<class T>
void List<T>::addToBack(const T& el)
{
	Stack<T> temp;
    //empty current stack in new stack
    //(creates reversed stack)
	while (!stack->isEmpty()){
		temp.push(stack->pop());
	}
    //push new last element
	stack->push(el);
    //push reversed stack back into current
    //stack(reverses reversed stack i.e corrects the order)
	while(!temp.isEmpty()){
		stack->push(temp.pop());
	}
}

template<class T>
void List<T>::insertAtIndex(const int& index, const T& el)
{
  //if index is 0 just add to front
  if(index == 0){
    addToFront(el);
  }else{
    int count = 0;
    Stack<T> temp;
    bool found = false;

    //empty current stack into new stack and place
    //new element at correct index
    //(order of new stack is reversed)
    while(!stack->isEmpty()){
        if(count == index){
            temp.push(el);	
            found = true;
        }
        temp.push(stack->pop());
        count++;
    }

    if(!found){
        throw MyException("Invalid index passed to List::insertAtIndex()");
    }	
    //pop new stack contents into current stack
    //(reversed stack is reversed, i.e. correctly ordered)
    while(!temp.isEmpty()){
        stack->push(temp.pop());
    }
  }
}

template<class T>
T List<T>::deleteAtIndex(const int& index)
{
  //same as insertAtIndex except we don't
  //put the value found at index back into the stack
	int count = 0;
	Stack<T> temp;
	bool found = false;
    T val;
	while(!stack->isEmpty()){
		if(count == index){
          val = stack->pop();
          found = true;
		}
        else{
          temp.push(stack->pop());
        }
		count++;
	}

	if(!found){
		throw MyException("Invalid index passed to List::insertAtIndex()");
	}	
	while(!temp.isEmpty()){
		stack->push(temp.pop());
	}
    return val;
	
}


template<class T>
T List<T>::get(const int& index)
{
  Stack<T> temp(*stack);	
  int count =0;
  while(!stack->isEmpty()){
    T val = temp.pop();
    if(count == index)
      return val;
    count++;
  }
  throw MyException("Invalid index passed to List::get()");
}

template<class T>
void List<T>::set(const int& index, const T& el)
{
  Stack<T> temp;	
  int count =0;
  bool found = false;
  T val;
  while(!stack->isEmpty()){
      val = stack->pop();
      if(count == index){
        found = true;
        //place new element instead of old
        //one
        temp.push(el);
      }
      else{
        temp.push(val);
      }
      count++;
  }
  while(!temp.isEmpty()){
      stack->push(temp.pop());
  }
  if(!found)
    throw MyException("Invalid index passed to List::set()");
	
}

template<class T>
bool List<T>::isEmpty()
{
  return stack->isEmpty();	
}

template<class T>
ostream& operator<<(ostream& os,List<T>& list)
{
  os << *list.stack;	
  return os;
}

