/*TODO: Provide the implementation for the Queue class in this file*/

template<class T>
Queue<T>::Queue()
{
  head = 0;	
}

template<class T>
Queue<T>::Queue(const Queue<T>& other)
{
  if(!other.head){
    head = 0;
  }else{
    head = new Node(other.head->element);
    Node* onode = other.head->next;
    Node* node = head;

    //clone linked list	
    while(onode){
      node->next = new Node(onode->element);
      node = node->next;
      onode = onode->next;
    }
  }
}

template<class T>
Queue<T>& Queue<T>::operator=(const Queue<T>& other)
{
  //delete current linked list if any
  if(!isEmpty()){
    while(!isEmpty()){
      dequeue();
    }
  }
  
  if(other.head){
    head = new Node(other.head->element);
    Node* onode = other.head->next;
    Node* node = head;

    //clone linked list	
    while(onode){
      node->next = new Node(onode->element);
      node = node->next;
      onode = onode->next;
    }
  }
  return *this;	
}

template<class T>
Queue<T>::~Queue()
{
  //dequeue until empty
  while(!isEmpty()){
    dequeue();
  }
}

template<class T>
void Queue<T>::enqueue(const T& el)
{
  //if queue empty
  if(isEmpty()){
    head = new Node(el);
  }
  else{
    Node* node = head;
    //find node
    while(node->next){
      node = node->next;
    }
    node->next = new Node(el);
  }
	
}

template<class T>
T Queue<T>::dequeue()
{
  if(isEmpty())
    throw MyException("Queue::dequeue() called on empty queue");
  //copy value 
  T val = head->element;

  //reset head node
  Node* n = head->next;	
  delete head;
  head = n;

  return val;
}

template<class T>
bool Queue<T>::isEmpty()
{
  return !head;	
}

template<class T>
void Queue<T>::increasePriority(const T& el)
{
  if(isEmpty())
    return;
  if(head->element == el)
    return;

  Node* node = head;
  Node* prev = 0;
  Node* next;

  //find node, prev
  while(node != 0){
    if(node->element == el)
      break;
    prev = node;
    node = node->next;
  }
  next = node->next;

  //RELINK NODES
  node->next = prev;
  prev->next = next;

  if(prev != head){
    //find prev node of prev(prev2)
    Node* prev2 = head;
    while(prev2->next != prev)
      prev2 = prev2->next;
    prev2->next = node;
  }else{
    //if prev node is head, node becomes new head(swap)
    head = node;
  }
  if(node == 0)
    return;
}

template<class T>
ostream& operator<<(ostream& os,Queue<T>& queue)
{
  Queue<T> temp(queue);
  os << "[";
  while( !temp.isEmpty() ){
    os << temp.dequeue();
    if (!temp.isEmpty()){
        os << ",";
    }
  }
  os << "]";
  return os;	
}
